from django.apps import AppConfig


class AuctionsConfig(AppConfig):
    name = 'auctions'
